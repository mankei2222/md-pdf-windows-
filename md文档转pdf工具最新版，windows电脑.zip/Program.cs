using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Markdig;
using Microsoft.Web.WebView2.WinForms;

namespace KnowledgeExporter;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

public sealed class MainForm : Form
{
    private readonly TextBox fileBox = new();
    private readonly Button chooseButton = new();
    private readonly Button exportButton = new();
    private readonly Label statusLabel = new();
    private readonly WebView2 preview = new();

    private string? currentMarkdownPath;
    private string? currentHtml;

    public MainForm()
    {
        Text = "Knowledge Exporter";
        StartPosition = FormStartPosition.CenterScreen;
        Width = 1080;
        Height = 760;
        MinimumSize = new System.Drawing.Size(760, 560);

        var mainLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            Padding = new Padding(14)
        };

        mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
        mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 86));
        mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var titlePanel = new Panel { Dock = DockStyle.Fill };
        var title = new Label
        {
            Text = "Markdown → PDF",
            AutoSize = true,
            Left = 4,
            Top = 4,
            Font = new System.Drawing.Font(
                "Microsoft YaHei UI",
                20,
                System.Drawing.FontStyle.Bold
            )
        };
        titlePanel.Controls.Add(title);

        var controlLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 3,
            RowCount = 2,
            Margin = new Padding(0),
        };

        controlLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        controlLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
        controlLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));

        controlLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        controlLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));

        fileBox.Dock = DockStyle.Fill;
        fileBox.ReadOnly = true;
        fileBox.Margin = new Padding(0, 4, 10, 4);

        chooseButton.Text = "选择 MD";
        chooseButton.Dock = DockStyle.Fill;
        chooseButton.Margin = new Padding(0, 4, 8, 4);
        chooseButton.Click += ChooseButton_Click;

        exportButton.Text = "导出 PDF";
        exportButton.Dock = DockStyle.Fill;
        exportButton.Margin = new Padding(0, 4, 0, 4);
        exportButton.Enabled = false;
        exportButton.Click += ExportButton_Click;

        statusLabel.Text = "请选择一个 Markdown 文件";
        statusLabel.Dock = DockStyle.Fill;
        statusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
        statusLabel.AutoEllipsis = true;

        controlLayout.Controls.Add(fileBox, 0, 0);
        controlLayout.Controls.Add(chooseButton, 1, 0);
        controlLayout.Controls.Add(exportButton, 2, 0);
        controlLayout.Controls.Add(statusLabel, 0, 1);
        controlLayout.SetColumnSpan(statusLabel, 3);

        preview.Dock = DockStyle.Fill;

        mainLayout.Controls.Add(titlePanel, 0, 0);
        mainLayout.Controls.Add(controlLayout, 0, 1);
        mainLayout.Controls.Add(preview, 0, 2);

        Controls.Add(mainLayout);

        Shown += MainForm_Shown;
    }

    private async void MainForm_Shown(object? sender, EventArgs e)
    {
        try
        {
            statusLabel.Text = "正在初始化预览组件...";
            await preview.EnsureCoreWebView2Async();

            currentHtml = BuildWelcomeHtml();
            preview.NavigateToString(currentHtml);

            statusLabel.Text = "请选择一个 Markdown 文件";
        }
        catch (Exception ex)
        {
            chooseButton.Enabled = false;
            exportButton.Enabled = false;

            MessageBox.Show(
                "WebView2 初始化失败。\n\n" +
                "请确认电脑已安装 Microsoft Edge WebView2 Runtime。\n\n" +
                ex.Message,
                "初始化失败",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
        }
    }

    private async void ChooseButton_Click(object? sender, EventArgs e)
    {
        using var dialog = new OpenFileDialog
        {
            Title = "选择 Markdown 文件",
            Filter = "Markdown 文件 (*.md)|*.md|所有文件 (*.*)|*.*"
        };

        if (dialog.ShowDialog() != DialogResult.OK)
            return;

        try
        {
            chooseButton.Enabled = false;
            exportButton.Enabled = false;
            statusLabel.Text = "正在读取 Markdown...";

            currentMarkdownPath = dialog.FileName;
            fileBox.Text = currentMarkdownPath;

            string markdownText = await File.ReadAllTextAsync(
                currentMarkdownPath,
                Encoding.UTF8
            );

            currentHtml = ConvertMarkdownToHtml(markdownText);
            preview.NavigateToString(currentHtml);

            exportButton.Enabled = true;
            statusLabel.Text = "预览完成，可以导出 PDF";
        }
        catch (Exception ex)
        {
            currentMarkdownPath = null;
            currentHtml = null;
            fileBox.Clear();

            MessageBox.Show(
                ex.Message,
                "读取失败",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );

            statusLabel.Text = "读取失败，请重新选择文件";
        }
        finally
        {
            chooseButton.Enabled = true;
        }
    }

    private async void ExportButton_Click(object? sender, EventArgs e)
    {
        if (preview.CoreWebView2 is null)
        {
            MessageBox.Show(
                "预览组件尚未初始化完成。",
                "提示",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning
            );
            return;
        }

        if (string.IsNullOrWhiteSpace(currentMarkdownPath) ||
            string.IsNullOrWhiteSpace(currentHtml))
        {
            MessageBox.Show(
                "请先选择 Markdown 文件。",
                "提示",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning
            );
            return;
        }

        string directory = Path.GetDirectoryName(currentMarkdownPath)!;
        string name = Path.GetFileNameWithoutExtension(currentMarkdownPath);

        using var dialog = new SaveFileDialog
        {
            Title = "保存 PDF",
            Filter = "PDF 文件 (*.pdf)|*.pdf",
            FileName = name + ".pdf",
            InitialDirectory = directory,
            OverwritePrompt = true
        };

        if (dialog.ShowDialog() != DialogResult.OK)
            return;

        string pdfPath = dialog.FileName;

        try
        {
            chooseButton.Enabled = false;
            exportButton.Enabled = false;
            statusLabel.Text = "正在生成 PDF...";

            bool success = await preview.CoreWebView2.PrintToPdfAsync(pdfPath);

            if (!success || !File.Exists(pdfPath))
                throw new InvalidOperationException("PDF 生成失败，请重新尝试。");

            statusLabel.Text = "PDF 导出完成";

            var answer = MessageBox.Show(
                "PDF 已成功生成。\n\n是否打开所在文件夹？",
                "完成",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information
            );

            if (answer == DialogResult.Yes)
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "explorer.exe",
                    Arguments = $"/select,\"{pdfPath}\"",
                    UseShellExecute = true
                });
            }
        }
        catch (Exception ex)
        {
            statusLabel.Text = "PDF 导出失败";

            MessageBox.Show(
                ex.Message,
                "导出失败",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
        }
        finally
        {
            chooseButton.Enabled = true;
            exportButton.Enabled = true;
        }
    }

    private static string ConvertMarkdownToHtml(string markdownText)
    {
        var pipeline = new MarkdownPipelineBuilder()
            .UseAdvancedExtensions()
            .Build();

        string body = Markdown.ToHtml(markdownText, pipeline);

        return BuildHtmlPage(body);
    }

    private static string BuildWelcomeHtml()
    {
        const string body = @"
<h1>Knowledge Exporter</h1>
<blockquote>
选择一个 <strong>.md</strong> 文件后，会在这里显示预览。<br>
确认排版后，点击上方的“导出 PDF”即可。
</blockquote>

<h2>支持内容</h2>
<ul>
<li>中文 / 日文</li>
<li>Markdown 标题</li>
<li>列表与表格</li>
<li>引用框</li>
<li>代码块</li>
<li>Emoji</li>
</ul>
";
        return BuildHtmlPage(body);
    }

    private static string BuildHtmlPage(string body)
    {
        string css = @"
@page {
    size: A4;
    margin: 16mm 15mm 18mm 15mm;
}

html {
    background: #eef2f6;
}

body {
    box-sizing: border-box;
    max-width: 900px;
    margin: 24px auto;
    padding: 44px 52px 60px;
    background: white;
    color: #243447;
    font-family:
        ""Yu Gothic"",
        ""Meiryo"",
        ""Microsoft YaHei"",
        ""Segoe UI Emoji"",
        sans-serif;
    font-size: 16px;
    line-height: 1.75;
}

h1 {
    color: #173e5d;
    font-size: 34px;
    line-height: 1.3;
    border-bottom: 4px solid #2f5f8f;
    padding-bottom: 12px;
    margin-top: 0;
}

h2 {
    color: #173e5d;
    font-size: 25px;
    border-left: 6px solid #2f5f8f;
    background: #eef5fb;
    padding: 7px 12px;
    margin-top: 34px;
}

h3 {
    color: #244f73;
    font-size: 20px;
    margin-top: 28px;
}

blockquote {
    background: #fff6df;
    border-left: 5px solid #d69a2d;
    padding: 12px 16px;
    margin: 18px 0;
    border-radius: 6px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin: 18px 0 24px;
}

th, td {
    border: 1px solid #d8dee8;
    padding: 9px 11px;
    vertical-align: top;
}

th {
    background: #e8f1f8;
    color: #173e5d;
}

img {
    max-width: 100%;
    height: auto;
}

pre {
    white-space: pre-wrap;
    overflow-wrap: anywhere;
    background: #f5f6f8;
    border: 1px solid #e2e6ec;
    border-radius: 7px;
    padding: 12px;
}

code {
    font-family: Consolas, ""Courier New"", monospace;
}

hr {
    border: 0;
    border-top: 1px solid #d8dee8;
    margin: 28px 0;
}

@media print {
    html {
        background: white;
    }

    body {
        max-width: none;
        margin: 0;
        padding: 0;
    }

    h1, h2, h3 {
        break-after: avoid;
    }

    blockquote, pre, img, table {
        break-inside: avoid;
    }
}
";

        return
            "<!doctype html>\n" +
            "<html lang=\"zh-CN\">\n" +
            "<head>\n" +
            "<meta charset=\"utf-8\">\n" +
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
            "<style>\n" + css + "\n</style>\n" +
            "</head>\n" +
            "<body>\n" +
            body +
            "\n</body>\n" +
            "</html>";
    }
}
