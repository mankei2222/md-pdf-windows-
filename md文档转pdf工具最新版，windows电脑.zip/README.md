# Knowledge Exporter V3

## 修正内容

- “选择 MD”按钮改为自动布局
- “导出 PDF”按钮改为自动布局
- 窗口缩放时按钮不会被裁掉
- 保留 WebView2 内部预览和 PDF 导出
- 不使用临时 HTML 文件
- 不调用 Edge 命令行

## 编译

PowerShell 进入本文件夹后运行：

```powershell
.\build_exe.bat
```

成功后 EXE 位于：

```text
bin\Release\net8.0-windows\win-x64\publish\KnowledgeExporter.exe
```

## 使用

1. 打开 KnowledgeExporter.exe
2. 上方一定可以看到：
   - 选择 MD
   - 导出 PDF
3. 点击“选择 MD”
4. 选择 Markdown 文件
5. 检查下方预览
6. 点击“导出 PDF”
