@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo Knowledge Exporter V3 - Build EXE
echo ==========================================
echo.

where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERROR: .NET SDK was not found.
  pause
  exit /b 1
)

echo [1/2] Restoring packages...
dotnet restore
if errorlevel 1 goto :error

echo.
echo [2/2] Publishing...
dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true
if errorlevel 1 goto :error

echo.
echo ==========================================
echo BUILD SUCCESS
echo.
echo EXE folder:
echo bin\Release\net8.0-windows\win-x64\publish
echo ==========================================
echo.

explorer "bin\Release\net8.0-windows\win-x64\publish"
pause
exit /b 0

:error
echo.
echo BUILD FAILED.
echo Please send a screenshot of the error above.
pause
exit /b 1
